export default {
  baseUrl: 'http://localhost:5000/api'
};
